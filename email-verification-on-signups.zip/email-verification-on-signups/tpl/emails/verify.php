<div style="direction: ltr; text-align: left;">
<h1>Hello {{name}},</h1>
<p>Thanks for registering on our site, please <a href="{{link}}" target="_blank">click here to confirm youremail address</a>.</p>

<p>If you are facing any problems with verifying your email address, try copying and pasting the below url to your browser</p>
<a href="{{link}}" target="_blank">{{link}}</a>
</div>